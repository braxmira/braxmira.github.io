"""A fun wordle game"""

__author__: str = "730548622"


import random
import string

WHITE_BOX: str = "\U00002B1C"
GREEN_BOX: str = "\U0001F7E9"
YELLOW_BOX: str = "\U0001F7E8"


def contains_char(searching_through: str, single_char: str) -> bool:
    """Search for single character in string and return True if found, if not False ."""
    assert len(single_char) == 1, f"len('{single_char}') is not 1"

    for char in searching_through:
        if char == single_char:
            return True

    return False


def emojified(guess_word: str, secret_word: str) -> str:
    """Returns an emoji string based on the guess_word and secret_word."""
    assert len(guess_word) == len(
        secret_word
    ), "Guess must be same length as secret_word"

    guess_result = ""
    for i in range(len(guess_word)):
        if guess_word[i] == secret_word[i]:
            guess_result += GREEN_BOX
        elif contains_char(secret_word, guess_word[i]):
            guess_result += YELLOW_BOX
        else:
            guess_result += WHITE_BOX

    return guess_result


def input_guess(expected_length: int) -> str:
    """Prompts the user for a guess_word of the expected length."""
    while True:
        persons_guess = input(f"Enter a {expected_length} character word:")
        if len(persons_guess) == expected_length:
            return persons_guess
        else:
            print(f"That wasn't {expected_length} chars! Try again:")


def main(secret: str) -> None:
    """The entrypoint of the program and main game loop."""
    max_turns = 6
    current_turn = 1
    print(f"Welcome to Wordle! Try to guess the secret word in {max_turns} turns.")
    while current_turn <= max_turns:
        print(f"=== Turn {current_turn}/{max_turns} ===")
        guess_word = input_guess(len(secret))
        guess_result = emojified(guess_word, secret)
        print(guess_result)

        if guess_word == secret:
            print(f"You won in {current_turn}/{max_turns} turns!")
            return
        current_turn += 1
    print(f"X/{max_turns} - Sorry, try again tomorrow!")


if __name__ == "__main__":
    # Generate a random 5-letter word
    secret_word = "".join(random.choice(string.ascii_lowercase) for _ in range(5))

    # Call the main function to start the game
    main(secret_word)
